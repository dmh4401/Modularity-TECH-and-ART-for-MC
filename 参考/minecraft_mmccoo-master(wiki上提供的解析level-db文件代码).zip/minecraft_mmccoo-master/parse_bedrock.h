

#ifndef PARSE_BEDROCK_HH
#define PARSE_BEDROCK_HH

#include <string>
#include <MinecraftWorld.h>


void parse_bedrock(std::string dbpath, MinecraftWorld &world);

#endif
