

#pragma once

#include <string>

#include <MinecraftWorld.h>

void GenerateVillageJSON(MinecraftWorld &world, std::string filename);
