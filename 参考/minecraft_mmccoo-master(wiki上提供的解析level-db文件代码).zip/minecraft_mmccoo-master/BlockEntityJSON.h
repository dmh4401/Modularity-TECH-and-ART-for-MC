

#pragma once

#include <string>

#include <MinecraftWorld.h>

void GenerateBlockEntityJSON(MinecraftWorld &world, std::string filename);
