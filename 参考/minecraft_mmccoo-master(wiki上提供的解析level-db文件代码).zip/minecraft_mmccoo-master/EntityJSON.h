


#pragma once

#include <MinecraftWorld.h>

void GenerateEntityJSON(MinecraftWorld &world, std::string filename);
